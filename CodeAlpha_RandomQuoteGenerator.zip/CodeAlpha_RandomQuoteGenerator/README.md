# CodeAlpha Random Quote Generator

A responsive Random Quote Generator built using HTML, CSS, and JavaScript for the CodeAlpha App Development Internship.

## Features
- Displays a random quote when the page opens
- New Quote button selects a different quote from the previous one
- Displays the quote author
- Copy Quote button
- Responsive layout for mobile and desktop
- Works offline; no external API is required

## Files
- `index.html` — webpage structure
- `style.css` — styling and responsive layout
- `script.js` — quote selection and copy functionality

## Run locally
1. Download or clone this repository.
2. Keep all three files in the same folder.
3. Open `index.html` in a modern browser.

## Technologies
HTML5, CSS3, JavaScript
