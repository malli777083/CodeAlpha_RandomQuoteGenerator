const quotes = [
    {
        text: "The future depends on what you do today.",
        author: "Mahatma Gandhi"
    },
    {
        text: "Believe you can and you're halfway there.",
        author: "Theodore Roosevelt"
    },
    {
        text: "It always seems impossible until it's done.",
        author: "Nelson Mandela"
    },
    {
        text: "Dream big and dare to fail.",
        author: "Norman Vaughan"
    },
    {
        text: "The secret of getting ahead is getting started.",
        author: "Mark Twain"
    },
    {
        text: "Learning never exhausts the mind.",
        author: "Leonardo da Vinci"
    },
    {
        text: "Stay hungry, stay foolish.",
        author: "Steve Jobs"
    },
    {
        text: "Do what you can, with what you have, where you are.",
        author: "Theodore Roosevelt"
    },
    {
        text: "Great things are done by a series of small things brought together.",
        author: "Vincent van Gogh"
    },
    {
        text: "Success is the sum of small efforts repeated daily.",
        author: "Robert Collier"
    }
];

const quoteElement = document.getElementById("quote");
const authorElement = document.getElementById("author");
const newQuoteButton = document.getElementById("new-quote");
const copyButton = document.getElementById("copy-quote");
const messageElement = document.getElementById("message");

let previousIndex = -1;

function showRandomQuote() {
    let index;

    do {
        index = Math.floor(Math.random() * quotes.length);
    } while (quotes.length > 1 && index === previousIndex);

    previousIndex = index;
    quoteElement.textContent = '"' + quotes[index].text + '"';
    authorElement.textContent = "— " + quotes[index].author;
    messageElement.textContent = "";
}

async function copyQuote() {
    const text = quoteElement.textContent + "\n" + authorElement.textContent;

    try {
        await navigator.clipboard.writeText(text);
        messageElement.textContent = "Quote copied successfully!";
    } catch (error) {
        messageElement.textContent =
            "Copy unavailable. Please copy the quote manually.";
    }
}

newQuoteButton.addEventListener("click", showRandomQuote);
copyButton.addEventListener("click", copyQuote);

showRandomQuote();
